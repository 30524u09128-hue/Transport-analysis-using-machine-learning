import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={"a" : 1,"b" : 2,"c" : 3,"d" : 4,"e" : 5
                            ,"f" : 6,"g" : 7,"h": 8,"i": 9,"j": 10,"k": 11,"l": 12,"m": 13,"n": 14,"o": 15 })

print(r.json())